package com.capg.exception;

public class BankException extends Exception {
	public BankException()
	{
		super();
	}
	public BankException(String msg)
	{
		super(msg);
	}
}
