package com.capg.dao;

import com.capg.bean.BankBean;

public interface BankDaoImpl {

	public BankBean checkAccount(long accNo);

	public void setData(long accNo, BankBean bean);

}
